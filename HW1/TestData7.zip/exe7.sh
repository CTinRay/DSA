#!/bin/bash
#usage ./exe7.sh ./Program < Input > Ouput

while read line           
do           
    echo $line | $1
done < /dev/stdin
